<?php include 'include/session.php'; ?>
<!DOCTYPE html>
<html lang="en">
  
  <?php include 'include/head.php'; ?>

  <body>
    <div id="preloader">
      <div class="sk-three-bounce">
        <div class="sk-child sk-bounce1"></div>
        <div class="sk-child sk-bounce2"></div>
        <div class="sk-child sk-bounce3"></div>
      </div>
    </div>
    <div id="main-wrapper">
      <!-- Include Header -->
      <?php include 'include/header.php'; ?>
      <!-- Include Menu -->
      <?php include 'include/menu.php'; ?>
      <br><br><br><br><br>
      
      <div class="content-body">
        <div class="container-fluid">
          <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12">
              <div class="row justify-content-center h-100 align-items-center">
                <div class="col-xl-5 col-md-6">
                    <div class="card">
                        <div class="card-header border-0 py-0">
                            <h4 class="text-center card-title">Swap</h4>
                        </div>
                        <div class="card-body">
                            <div class="buy-sell-widget">
                                <form method="post" name="myform" class="currency_validate" novalidate="novalidate">
                                    <div class="form-group">
                                        <label class="mr-sm-2">Currency</label>
                                        <div class="input-group mb-3">
                                            <div class="input-group-prepend">
                                                <label class="input-group-text"><i class="cc BTC-alt"></i></label>
                                            </div>
                                            <select name="currency" class="form-control">
                                                <option value="">Select</option>
                                                <option value="bitcoin">Bitcoin</option>
                                                <option value="litecoin">Litecoin</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="mr-sm-2">Currency</label>
                                        <div class="input-group mb-3">
                                            <div class="input-group-prepend">
                                                <label class="input-group-text"><i class="fa fa-bank"></i></label>
                                            </div>
                                            <select class="form-control" name="method">
                                                <option value="">Select</option>
                                                <option value="bitcoin">Bitcoin</option>
                                                <option value="litecoin">Litecoin</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="mr-sm-2">Enter your amount</label>
                                        <div class="input-group">
                                            <input type="text" name="currency_amount" class="form-control" placeholder="0.0214 BTC">
                                        </div>
                                        <!-- <div class="d-flex justify-content-between mt-3">
                                            <p class="mb-0">Monthly Limit</p>
                                            <h6 class="mb-0">$49750 remaining</h6>
                                        </div> -->
                                    </div>
                                    <button type="submit" name="submit" class="btn btn-primary btn-block">Swap Now</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script
      data-cfasync="false"
      src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"
    ></script>
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/waves/waves.min.js"></script>
    <script src="vendor/validator/jquery.validate.js"></script>
    <script src="vendor/validator/validator-init.js"></script>
    <script src="vendor/scrollit/scrollIt.js"></script>
    <script src="js/plugins/scrollit-init.js"></script>
    <script src="js/scripts.js"></script>
    <script src="js/settings.js"></script>
    <script src="js/quixnav-init.js"></script>
    <script src="js/styleSwitcher.js"></script>
    <script src="vendor/magnific-popup/magnific-popup.js"></script>
    <script src="vendor/magnific-popup/magnific-popup-init.js"></script>
    <script src="vendor/validator/jquery.validate.js"></script>
    <script src="vendor/validator/validator-init.js"></script>
    
  </body>
</html>