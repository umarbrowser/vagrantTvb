<?php include 'include/session.php'; ?>
<?php include 'include/withdraw-process.php'; ?>
<!DOCTYPE html>
<html lang="en">
  
  <?php include 'include/head.php'; ?>

  <body>
    <div id="preloader">
      <div class="sk-three-bounce">
        <div class="sk-child sk-bounce1"></div>
        <div class="sk-child sk-bounce2"></div>
        <div class="sk-child sk-bounce3"></div>
      </div>
    </div>
    <div id="main-wrapper">
      <!-- Include Header -->
      <?php include 'include/header.php'; ?>
      <!-- Include Menu -->
      <?php include 'include/menu.php'; ?><br><br><br>
      
      <div class="content-body">
        <div class="container-fluid">
          <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12">
              <div class="row justify-content-center h-100 align-items-center">
                <div class="col-xl-5 col-md-5">
                    <?php if (isset($_POST['withdraw-ngn'])) {
                        // Declaring Variable for withdrawe
                        $withdrawAmount = $_POST['withdrawAmount'];
                        $withdrawMethod = $_POST['withdrawMethod'];
                        $withdrawWalletOption = $_POST['withdrawWalletOption'];
                        $active = 'active';
                        if ($withdrawWalletOption == 'withdraw-reven') {
                            // Select Revan active User
                            if (
                                $stmt = $link->prepare(
                                    'SELECT * FROM raven WHERE status= ? ORDER BY RAND() LIMIT 1'
                                )
                            ) {
                                // Bind parameters (s = string, i = int, b = blob, etc), hash the password using the PHP password_hash function.
                                $stmt->bind_param('s', $active);
                                $stmt->execute();
                                $stmt->store_result(); // Store the result so we can check if the account exists in the database.
                                if ($stmt->num_rows > 0) {
                                    // All User Information
                                    // output data of each row
                                    if ($stmt->fetch()) {

                                        $raven_user_id = $user_id;
                                        // All User Information
                                        $sql = "SELECT * FROM raven WHERE user_id = '$raven_user_id' ";
                                        $result = $link->query($sql);
                                        // output data of each row
                                        while ($row = $result->fetch_assoc()) {
                                            $raven_identity = $row['identity'];
                                        }
                                        // All User Information
                                        $sql = "SELECT * FROM users WHERE id = '$raven_user_id' ";
                                        $result = $link->query($sql);
                                        // output data of each row
                                        while ($row = $result->fetch_assoc()) {
                                            $raven_user_fullname =
                                                $row['fullname'];
                                        } // Generate Transaction Narration
                                        $permitted_chars =
                                            '0123456789abcdefghijklmnopqrstuvwxyz';
                                        $transaction_narration = strtoupper(
                                            substr(
                                                str_shuffle($permitted_chars),
                                                0,
                                                15
                                            )
                                        );
                                        ?>
                                        <div class="auth-form card">
                                            <div class="card-header justify-content-center" bis_skin_checked="1">
                                                <span class="card-title text-center" style="font-size: 21px;">
                                                    Peer withdraw Merchant
                                                    <br>
                                                    <span style="font-size: 12px;color: #10d876; ">Verified by Agpay</span>
                                                </span>
                                            </div>
                                            <div class="card-body" bis_skin_checked="1">
                                            <form name="" action="" method="POST" class="" novalidate="novalidate">

                                                <input type="hidden" name="raven_user_id" value="<?php echo $raven_user_id; ?>">
                                                <input type="hidden" name="transaction_narration" value="<?php echo $transaction_narration; ?>">
                                                <input type="hidden" name="withdrawAmount" value="<?php echo $withdrawAmount; ?>">
                                                <input type="hidden" name="withdrawMethod" value="<?php echo $withdrawMethod; ?>">
                                                <input type="hidden" name="withdrawWalletOption" value="<?php echo $withdrawWalletOption; ?>">
                                                <input type="hidden" name="raven_identity" value="<?php echo $raven_identity; ?>">
                                                
                                                <div class="form-group" bis_skin_checked="1">
                                                    <div class="card-body">
                                                        <h3 class="text-center"><?php echo htmlentities(
                                                            $raven_identity
                                                        ); ?> <i class="la la-copy"></i></h3>
                                                    </div>
                                                    <div class="alert text-center alert-primary" role="alert">
                                                        Transfer Narration<br>
                                                        <h4 class="text-primary"><?php echo htmlentities(
                                                            $transaction_narration
                                                        ); ?></h4>
                                                    </div>
                                                    <p style="font-size: 14px;">
                                                        1. Click on the merchant name to copy <br>
                                                        2. Click on the blue area to copy your unique narration. <br>
                                                        3. Make sure to use this narration above for the transfer <br>
                                                        4. Money must be transferred from your own Raven account, else funds will be returned by the merchant.
                                                    </p>
                                                </div>      
                                                <div class="text-center mt-4" bis_skin_checked="1">
                                                    <button type="submit" name="complate-withdraw" id="btn-submit" class="btn btn-primary p-2 fs-10 btn-block btn-sm">
                                                        Complate withdraw
                                                    </button>
                                                </div>
                                                <p class="p-2 text-danger" style="font-size: 14px;">
                                                    Note: Lorem ipsum dolor sit amet consectetur adipisicing elit.
                                                    Modi cupiditate suscipit explicabo voluptas eos in tenetur error
                                                    temporibus dolorum. Nulla!
                                                </p>
                                            </form>
                                            </div>
                                        </div>
                                  <?php
                                    }
                                } else {
                                    // Email Address already exists
                                    echo '<div class="alert alert-danger">Email address exists, please choose another!</div>';
                                }
                            }
                        }
                    } ?>
                </div>
              </div>
            </div>
          </div>   
        </div>
      </div>
    </di>
    <script
      data-cfasync="false"
      src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"
    ></script>
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/waves/waves.min.js"></script>
    <script src="vendor/validator/jquery.validate.js"></script>
    <script src="vendor/validator/validator-init.js"></script>
    <script src="vendor/scrollit/scrollIt.js"></script>
    <script src="js/plugins/scrollit-init.js"></script>
    <script src="js/scripts.js"></script>
    <script src="js/settings.js"></script>
    <script src="js/quixnav-init.js"></script>
    <script src="js/styleSwitcher.js"></script>
    <script src="vendor/magnific-popup/magnific-popup.js"></script>
    <script src="vendor/magnific-popup/magnific-popup-init.js"></script>
    <script src="vendor/validator/jquery.validate.js"></script>
    <script src="vendor/validator/validator-init.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script>
      $(document).ready(function(){
          $("#withdraw-method").change(function(){
              $(this).find("option:selected").each(function(){
                  var optionValue = $(this).attr("value");
                  if(optionValue == "mobile-wallet"){
                      $("#mobile-wallet-container").show();
                      $("#bank-tranfer-container").hide();
                  }else if(optionValue == "bank-tranfer"){
                      $("#mobile-wallet-container").hide();
                      $("#bank-tranfer-container").show();
                  } else{
                      $(".box").hide();
                  }
              });
          }).change();
      });
    </script>
    
  </body>
</html>