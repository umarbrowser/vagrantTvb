<?php include 'include/session.php'; ?>
<!DOCTYPE html>
<html lang="en">
  
  <?php include 'include/head.php'; ?>

  <body>
    <div id="preloader">
      <div class="sk-three-bounce">
        <div class="sk-child sk-bounce1"></div>
        <div class="sk-child sk-bounce2"></div>
        <div class="sk-child sk-bounce3"></div>
      </div>
    </div>
    <div id="main-wrapper">
      <!-- Include Header -->
      <?php include 'include/header.php'; ?>
      <!-- Include Menu -->
      <?php include 'include/menu.php'; ?>
      <div class="content-body"><br><br><br>
        <div class="container-fluid">
          <div class="row">
            <div class="col-xl-1"></div>
            <div class="col-xl-10">
              <?php
              $sql = "SELECT * FROM transactions WHERE user_id = '$user_id' ORDER BY id DESC LIMIT 10";
              $result = $link->query($sql);

              if ($result->num_rows > 0) { ?>
                <div class="card">
                  <div class="card-header border-0">
                    <h4 class="card-title">Transaction History</h4>
                  </div>
                  <div class="card-body pt-0">
                    <div class="transaction-table">
                      <div class="table-responsive">
                        <table class="table mb-0 table-responsive-sm">
                          <tbody>
                            <?php while ($row = $result->fetch_assoc()) {
                                if ($row['trx_type'] == 'DEPOSIT') { ?>
                            <tr>
                              <td>
                                <span class="buy-thumb">
                                  <i class="la la-arrow-up"></i>
                                </span>
                              </td>
                              <td>Wallet Deposit</td>
                              <td>
                                <?php echo htmlentities($row['currency']); ?>
                              </td>
                              <td>Deposit of <?php echo number_format(
                                  htmlentities($row['trx_amount']),
                                  2
                              ); ?> <?php echo htmlentities(
     $row['currency']
 ); ?> to your Wallet</td>
                              <td class="text-success">
                              <?php
                              echo number_format(
                                  htmlentities($row['trx_amount']),
                                  2
                              );
                              echo '&nbsp';
                              echo htmlentities($row['currency']);
                              ?>
                              </td>
                            </tr>
                            <?php } elseif ($row['trx_type'] == 'WITHDRAW') { ?>
                            <tr>
                              <td>
                                <span class="sold-thumb">
                                  <i class="la la-arrow-up"></i>
                                </span>
                              </td>
                              <td>
                                <span class="badge badge-success">Buy</span>
                              </td>
                              <td>
                                <i class="cc LTC"></i>
                                LTC
                              </td>
                              <td>Using - Card *******8475</td>
                              <td class="text-success">
                                -0.000242 BTC
                              </td>
                              <td>-0.125 USD</td>
                            </tr>
                            <?php } elseif ($row['trx_type'] == 'TRANSFER') { ?>
                            <?php if ($row['trx_sender'] == $user_email) { ?>
                            <tr>
                              <td>
                                <span class="sold-thumb">
                                  <i class="la la-arrow-down"></i>
                                </span>
                              </td>
                              <td>Wallet Transfer</td>
                              <td>
                                <?php echo htmlentities($row['currency']); ?>
                              </td>
                              <td>Deposit of <?php echo number_format(
                                  htmlentities($row['trx_amount']),
                                  2
                              ); ?> <?php echo htmlentities(
     $row['currency']
 ); ?> to your Wallet</td>
                              <td class="text-danger">
                              <?php
                              echo number_format(
                                  htmlentities($row['trx_amount']),
                                  2
                              );
                              echo '&nbsp';
                              echo htmlentities($row['currency']);
                              ?>
                              </td>
                            </tr>
                            <?php } else { ?>
                              <tr>
                              <td>
                                <span class="buy-thumb">
                                  <i class="la la-arrow-up"></i>
                                </span>
                              </td>
                              <td>Wallet Transfer</td>
                              <td>
                                <?php echo htmlentities($row['currency']); ?>
                              </td>
                              <td>Deposit of <?php echo number_format(
                                  htmlentities($row['trx_amount']),
                                  2
                              ); ?> <?php echo htmlentities(
     $row['currency']
 ); ?> to your Wallet</td>
                              <td class="text-success">
                              <?php
                              echo number_format(
                                  htmlentities($row['trx_amount']),
                                  2
                              );
                              echo '&nbsp';
                              echo htmlentities($row['currency']);
                              ?>
                              </td>
                            </tr>
                            <?php }}
                            } ?>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              <?php } else {echo '0 results';}
              ?>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/waves/waves.min.js"></script>
    <script src="vendor/validator/jquery.validate.js"></script>
    <script src="vendor/validator/validator-init.js"></script>
    <script src="vendor/scrollit/scrollIt.js"></script>
    <script src="js/plugins/scrollit-init.js"></script>
    <script src="js/scripts.js"></script>
    <script src="js/settings.js"></script>
    <script src="js/quixnav-init.js"></script>
    <script src="js/styleSwitcher.js"></script>
  </body>
</html>
