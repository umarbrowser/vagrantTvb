<?php include 'include/session.php'; ?>
<?php if (isset($_GET['method'])) {
    $method = $_GET['method']; ?>
<!DOCTYPE html>
<html lang="en">
  
  <?php include 'include/head.php'; ?>

  <body>
    <div id="preloader">
      <div class="sk-three-bounce">
        <div class="sk-child sk-bounce1"></div>
        <div class="sk-child sk-bounce2"></div>
        <div class="sk-child sk-bounce3"></div>
      </div>
    </div>
    <div id="main-wrapper">
      <!-- Include Header -->
      <?php include 'include/header.php'; ?>
      <!-- Include Menu -->
      <?php include 'include/menu.php'; ?><br><br><br><br>
      
      <div class="content-body">
        <div class="container-fluid">
          <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12">
              <div class="row justify-content-center h-100 align-items-center">
                <div class="col-xl-5 col-md-5">
                    <?php if ($method === 'deposit') { ?>
                        <div class="auth-form card">
                            <div class="card-body" bis_skin_checked="1">

                                <div class="form-group" bis_skin_checked="1">
                                    <div class="card-body">
                                        <h2 class="text-center" style="font-size: 100px; color: #10d876; ">
                                            <i class="la la-check-circle"></i>
                                        </h2>
                                    </div>
                                    <h4 class="text-center">
                                        your deposit was successful
                                    </h4>
                                </div>      
                                <div class="text-center mt-4" bis_skin_checked="1">
                                    <a href="<?php echo $agpay_url; ?>" class="btn btn-primary p-2 fs-10  btn-sm">
                                        Dashboard
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php } elseif ($method === 'transfer') { ?>
                        <div class="auth-form card">
                            <div class="card-body" bis_skin_checked="1">

                                <div class="form-group" bis_skin_checked="1">
                                    <div class="card-body">
                                        <h2 class="text-center" style="font-size: 100px; color: #10d876; ">
                                            <i class="la la-check-circle"></i>
                                        </h2>
                                    </div>
                                    <h4 class="text-center">
                                      Your Transfer was Successfully Sent
                                      </h4>
                                    </div>      
                                    <div class="text-center mt-4" bis_skin_checked="1">
                                    <a href="<?php echo $agpay_url; ?>" class="btn btn-primary p-2 fs-10  btn-sm">
                                        Dashboard
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                </div>
              </div>
            </div>
          </div>   
        </div>
      </div>
    </di>
    <script
      data-cfasync="false"
      src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"
    ></script>
    <script src="<?php echo $agpay_url; ?>vendor/jquery/jquery.min.js"></script>
    <script src="<?php echo $agpay_url; ?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo $agpay_url; ?>vendor/waves/waves.min.js"></script>
    <script src="<?php echo $agpay_url; ?>vendor/validator/jquery.validate.js"></script>
    <script src="<?php echo $agpay_url; ?>vendor/validator/validator-init.js"></script>
    <script src="<?php echo $agpay_url; ?>vendor/scrollit/scrollIt.js"></script>
    <script src="<?php echo $agpay_url; ?>js/plugins/scrollit-init.js"></script>
    <script src="<?php echo $agpay_url; ?>js/scripts.js"></script>
    <script src="<?php echo $agpay_url; ?>js/settings.js"></script>
    <script src="<?php echo $agpay_url; ?>js/quixnav-init.js"></script>
    <script src="<?php echo $agpay_url; ?>js/styleSwitcher.js"></script>
    <script src="<?php echo $agpay_url; ?>vendor/magnific-popup/magnific-popup.js"></script>
    <script src="<?php echo $agpay_url; ?>vendor/magnific-popup/magnific-popup-init.js"></script>
    <script src="<?php echo $agpay_url; ?>vendor/validator/jquery.validate.js"></script>
    <script src="<?php echo $agpay_url; ?>vendor/validator/validator-init.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    
  </body>
</html>
<?php
} ?>
