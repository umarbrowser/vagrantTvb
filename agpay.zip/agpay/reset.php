<?php include 'include/reset-password.php'; ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Agpay Wallet - Reset Password</title>
                <link
            rel="shortcut icon"
            href="images/favicon.png"
            type="image/x-icon"
        />
        <link rel="stylesheet" href="css/dark-style.css" />
    </head>

    <body>
        <div id="preloader">
            <div class="sk-three-bounce">
                <div class="sk-child sk-bounce1"></div>
                <div class="sk-child sk-bounce2"></div>
                <div class="sk-child sk-bounce3"></div>
            </div>
        </div> 
        <div id="main-wrapper">
            <div class="authincation section-padding">
                <div class="container h-100">
                    <div class="row justify-content-center h-100 align-items-center">
                        <div class="col-xl-5 col-md-6">
                            <div class="mini-logo text-center my-5">
                                <img src="./images/m_logo.png" alt="" />
                            </div>
                            <div class="auth-form card">
                                <div class="card-header justify-content-center">
                                    <h4 class="card-title">Reset Password</h4>
                                </div>
                                <div class="card-body">
                                    <form
                                        name="myform"
                                        class=""
                                        novalidate="novalidate"
                                        action=""
                                        method="POST"
                                    >   <?php echo $respon; ?>      
                                        <div class="form-group">
                                            <label>Email</label>
                                            <input
                                                type="email"
                                                class="form-control"
                                                placeholder="hello@example.com"
                                                name="email" value=""
                                                required
                                                />
                                            <span class="text-danger"></span>
                                        </div>
                                        <div class="text-center">
                                            <button type="submit" name="btn-reset" class="btn btn-success btn-block">
                                                Reset Now
                                            </button>
                                        </div>
                                    </form>
                                    <div class="new-account mt-3">
                                        <p>
                                            Already have an account?
                                            <a class="text-primary" href="login">
                                                Sign in
                                            </a>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="vendor/jquery/jquery.min.js"></script>
        <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="vendor/waves/waves.min.js"></script>
        <script src="vendor/validator/jquery.validate.js"></script>
        <script src="vendor/validator/validator-init.js"></script>
        <script src="vendor/scrollit/scrollIt.js"></script>
        <script src="js/plugins/scrollit-init.js"></script>
        <script src="js/scripts.js"></script>
        <script src="js/settings.js"></script>
        <script src="js/quixnav-init.js"></script>
        <script src="js/styleSwitcher.js"></script>
     </body>
</html>
