<?php

include 'include/dbcon.php';

// First we check if the email and code exists...
if (isset($_GET['code'])) {
    if (
        $stmt = $link->prepare('SELECT * FROM users WHERE activation_code = ?')
    ) {
        $stmt->bind_param('s', $_GET['code']);
        $stmt->execute();
        // Store the result so we can check if the account exists in the database.
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            // Account exists with the requested email and code.
            if (
                $stmt = $link->prepare(
                    'UPDATE users SET activation_code = ? WHERE activation_code = ?'
                )
            ) {
                // Set the new activation code to 'activated', this is how we can check if the user has activated their account.
                $newcode = 'activated';
                $stmt->bind_param('ss', $newcode, $_GET['code']);
                $stmt->execute();

                echo "<script>alert('Your account is now activated! You can now!'); window.location='../login'</script>";
            }
        } else {
            echo "<script>alert('The account is already activated or doesnt exist!'); window.location='../login'</script>";
        }
    } else {
        echo "<script>window.location='../login'</script>";
    }
} else {
    echo "<script>window.location='../login'</script>";
}
?>
