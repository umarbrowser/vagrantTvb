<?php

include 'include/dbcon.php';
use csrfhandler\csrf as csrf;

if (isset($_POST['btn-signup'])) {
    $isValid = csrf::post();
    if ($isValid) {
        $recaptcha_url = 'https://www.google.com/recaptcha/api/siteverify';
        $secret_key = '6LemGz8eAAAAAILPJE0xKbokXVKhtrEnE7uxKrx1';
        $recaptcha_response = $_POST['recaptcha_response'];
        $get_recaptcha_response = file_get_contents(
            $recaptcha_url .
                '?secret=' .
                $secret_key .
                '&response=' .
                $recaptcha_response
        );
        $response_json = json_decode($get_recaptcha_response);

        if (
            $response_json->success == true &&
            $response_json->score >= 0.5 &&
            $response_json->action == 'submit'
        ) {
            // Now we check if the data was submitted, isset() function will check if the data exists.
            if (
                !isset($_POST['fullname'], $_POST['password'], $_POST['email'])
            ) {
                // Could not get the data that should have been sent.
                echo '<div class="alert alert-danger">Please complete the registration form</div>';
                // exit('Please complete the registration form!');
            } else {
                // Make sure the submitted registration values are not empty.
                if (
                    empty($_POST['fullname']) ||
                    empty($_POST['password']) ||
                    empty($_POST['email'])
                ) {
                    // One or more values are empty.
                    echo '<div class="alert alert-danger">Please complete the registration form</div>';
                    // exit('Please complete the registration form');
                } else {
                    if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
                        exit('Email is not valid!');
                    } else {
                        if (
                            preg_match(
                                '/^[a-zA-Z0-9]+$/',
                                $_POST['fullname']
                            ) == 0
                        ) {
                            echo '<div class="alert alert-danger">Username is not valid!</div>';
                        } else {
                            if (
                                strlen($_POST['password']) > 20 ||
                                strlen($_POST['password']) < 5
                            ) {
                                exit(
                                    'Password must be between 5 and 20 characters long!'
                                );
                            } else {
                                // We need to check if the account with that fullname exists.
                                if (
                                    $stmt = $link->prepare(
                                        'SELECT id, password FROM users WHERE email = ?'
                                    )
                                ) {
                                    // Bind parameters (s = string, i = int, b = blob, etc), hash the password using the PHP password_hash function.
                                    $stmt->bind_param('s', $_POST['email']);
                                    $stmt->execute();
                                    $stmt->store_result();
                                    // Store the result so we can check if the account exists in the database.
                                    if ($stmt->num_rows > 0) {
                                        // Email Address already exists
                                        echo '<div class="alert alert-danger">Email address exists, please choose another!</div>';
                                    } else {
                                        // Generate User ID
                                        $permitted_chars =
                                            '0123456789abcdefghijklmnopqrstuvwxyz';
                                        $rand = strtoupper(
                                            substr(
                                                str_shuffle($permitted_chars),
                                                0,
                                                12
                                            )
                                        );
                                        $cname = 'AGP';
                                        $user_id = $cname . $rand;

                                        //Generate Activation Code
                                        $activation_code = substr(
                                            str_shuffle($permitted_chars),
                                            0,
                                            30
                                        );

                                        // Email Address doesnt exists, insert new account
                                        if (
                                            $stmt = $link->prepare(
                                                'INSERT INTO users (id, fullname, password, email, activation_code) VALUES (?, ?, ?, ?, ?)'
                                            )
                                        ) {
                                            // We do not want to expose passwords in our database, so hash the password and use password_verify when a user logs in.
                                            $password = password_hash(
                                                $_POST['password'],
                                                PASSWORD_DEFAULT
                                            );
                                            $stmt->bind_param(
                                                'sssss',
                                                $user_id,
                                                $_POST['fullname'],
                                                $password,
                                                $_POST['email'],
                                                $activation_code
                                            );
                                            $stmt->execute();
                                            echo '<div class="alert alert-success">You have successfully registered, you can now login!</div>';
                                            //sent Email for User Activation
                                            // User Full name, Email, Activation Code
                                            // include('include/activation-email.php');
                                            $activate_link =
                                                'http://agpay.ng/activate/$activation_code';
                                        } else {
                                            // Something is wrong with the sql statement, check to make sure accounts table exists with all 3 fields.
                                            echo '<div class="alert alert-danger">Could not prepare statement!</div>';
                                        }
                                    }
                                    $stmt->close();
                                } else {
                                    // Something is wrong with the sql statement, check to make sure accounts table exists with all 3 fields.
                                    echo '<div class="alert alert-danger">Could not prepare statement!</div>';
                                }
                            }
                        }
                    }
                }
            }
        } else {
            echo '<div class="alert alert-danger">Please try again!</div>';
        }
    } else {
        //
        echo '<div class="alert alert-danger">Please try again!</div>';
    }
}
$link->close();
?>
