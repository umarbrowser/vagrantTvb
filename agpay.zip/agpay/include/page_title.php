    <div class="page_title d-block">
        <div class="container-fluid">
          <div class="row">
            <div class="col-xl-12">
              <div class="page_title-content">
                <p>
                  Welcome Back,
                  <span><?php
                  $arr1 = explode(' ', trim($user_fullname));
                  echo htmlentities($arr1[0]);
                  ?></span>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>