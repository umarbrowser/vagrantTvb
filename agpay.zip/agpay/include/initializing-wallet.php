<?php

// Initializing Naira Wallat
if ($stmt = $link->prepare('SELECT user_id FROM ngn WHERE user_id = ?')) {
    // Bind parameters (s = string, i = int, b = blob, etc), hash the password using the PHP password_hash function.
    $stmt->bind_param('s', $user_id);
    $stmt->execute();
    $stmt->store_result();
    // Store the result so we can check if the wallet exists in the database.
    if ($stmt->num_rows == 0) {
        // Naira wallet doesnt exists, insert new wallet
        $balance = '0.000000000000000000';
        if (
            $stmt = $link->prepare(
                'INSERT INTO ngn (user_id, balance) VALUES (?, ?)'
            )
        ) {
            $stmt->bind_param('ss', $user_id, $balance);
            $stmt->execute();
        }
    }
    $stmt->close();
}

// Initializing Agrikoin Wallat
if ($stmt = $link->prepare('SELECT user_id FROM agk WHERE user_id = ?')) {
    // Bind parameters (s = string, i = int, b = blob, etc), hash the password using the PHP password_hash function.
    $stmt->bind_param('s', $user_id);
    $stmt->execute();
    $stmt->store_result();
    // Store the result so we can check if the wallet exists in the database.
    if ($stmt->num_rows == 0) {
        // Naira wallet doesnt exists, insert new wallet
        $balance = '0.000000000000000000';
        if (
            $stmt = $link->prepare(
                'INSERT INTO agk (user_id, balance) VALUES (?, ?)'
            )
        ) {
            $stmt->bind_param('ss', $user_id, $balance);
            $stmt->execute();
        }
    }
    $stmt->close();
}

?>
