<?php

// Select USD Price
$sql = "SELECT * FROM currencies WHERE symbol= 'USD' ";
$result = $link->query($sql);
// output data of each row
while ($row = $result->fetch_assoc()) {
    $usd_price = $row['price'];
    $usd_symbol = $row['symbol'];
    $usd_24h_change = $row['24h_change'];
}

// Select NGN Price
$sql = "SELECT * FROM currencies WHERE symbol= 'NGN' ";
$result = $link->query($sql);
// output data of each row
while ($row = $result->fetch_assoc()) {
    $ngn_price = $row['price'];
    $ngn_symbol = $row['symbol'];
    $ngn_24h_change = $row['24h_change'];
}

// Select AGK Price
$sql = "SELECT * FROM currencies WHERE symbol= 'AGK' ";
$result = $link->query($sql);
// output data of each row
while ($row = $result->fetch_assoc()) {
    $agk_price = $row['price'];
    $agk_symbol = $row['symbol'];
    $agk_24h_change = $row['24h_change'];
}
