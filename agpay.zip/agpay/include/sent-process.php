<?php
$sent_status = '';
$sent_respon = '';
if (isset($_POST['sentngn'])) {
    // Check if email is empty
    if (!empty(trim($_POST['email']))) {
        $email = trim($_POST['email']);

        // Check if email is empty
        if (!empty(trim($_POST['amount']))) {
            $sent_amount = trim($_POST['amount']);
            $sent_email = trim($_POST['email']);
            $sent_narration = trim($_POST['sent_narration']);

            if (filter_var($sent_amount, FILTER_VALIDATE_INT) !== false) {
                // Select user sentder  balance
                $sql = 'SELECT * FROM users WHERE email = ?';

                if ($stmt = $link->prepare($sql)) {
                    // Bind variables to the prepared statement as parameters
                    $stmt->bind_param('s', $sent_email);

                    // Attempt to execute the prepared statement
                    if ($stmt->execute()) {
                        // Store result
                        $stmt->store_result();

                        // Check if email exists, if yes then verify password
                        if ($stmt->num_rows == 1) {
                            if ($sent_email != $user_email) {
                                if ($sent_amount < 50) {
                                    $sent_respon =
                                        '<div class="alert alert-danger text-center" role="alert">Cannot sent less then 50 NGN</div>';
                                } elseif ($sent_amount > $ngn_balance) {
                                    $sent_respon =
                                        '<div class="alert alert-danger text-center" role="alert">Insufficient Balance. Please make sure your account is Funded</div>';
                                } elseif ($sent_amount <= $ngn_balance) {
                                    $new_sender_balance =
                                        $ngn_balance - $sent_amount;
                                    // Update sender user balance
                                    if (
                                        $stmt = $link->prepare(
                                            'UPDATE ngn SET balance = ? WHERE user_id = ? '
                                        )
                                    ) {
                                        $stmt->bind_param(
                                            'ss',
                                            $new_sender_balance,
                                            $user_id
                                        );
                                        $stmt->execute();

                                        // Get reciver user id
                                        $sql = "SELECT * FROM users WHERE email= '$sent_email' ";
                                        $result = $link->query($sql);
                                        // output data of each row
                                        while ($row = $result->fetch_assoc()) {
                                            $reciver_id = $row['id'];
                                        }

                                        // Get reciver user Balance
                                        $sql = "SELECT * FROM ngn WHERE user_id= '$reciver_id' ";
                                        $result = $link->query($sql);
                                        // output data of each row
                                        while ($row = $result->fetch_assoc()) {
                                            $reciver_balance = $row['balance'];
                                        }
                                        $reciver_new_balance =
                                            $reciver_balance + $sent_amount;

                                        // Update reciver user balance
                                        if (
                                            $stmt = $link->prepare(
                                                'UPDATE ngn SET balance = ? WHERE user_id = ? '
                                            )
                                        ) {
                                            $stmt->bind_param(
                                                'ss',
                                                $reciver_new_balance,
                                                $reciver_id
                                            );
                                            $stmt->execute();

                                            // Create transaction information
                                            $user_id = $user_id;
                                            $trx_amount = $sent_amount;
                                            $fee = 0.0;
                                            $fee_currency = 'NGN';
                                            $currency = 'NGN';

                                            $trx_sender = $user_email;
                                            $permitted_chars =
                                                '012345678912345678abcdefghijklmnopqrstuvwxyz';

                                            $trx_hash =
                                                'TSF' .
                                                substr(
                                                    str_shuffle(
                                                        $permitted_chars
                                                    ),
                                                    0,
                                                    65
                                                );
                                            $trx_ref =
                                                'ngn' .
                                                substr(
                                                    str_shuffle(
                                                        $permitted_chars
                                                    ),
                                                    0,
                                                    12
                                                );
                                            $trx_type = 'TRANSFER';
                                            $trx_status = 'SUCCESS';
                                            $trx_description =
                                                'Account funded using Transfer from: ' .
                                                $user_email .
                                                'to' .
                                                $sent_email;
                                            $trx_to = $sent_email;
                                            $transaction_narration = $sent_narration;

                                            if (
                                                $stmt = $link->prepare(
                                                    'INSERT INTO transactions (user_id, trx_amount, fee, fee_currency, currency, trx_sender, trx_hash, trx_ref, trx_type, trx_status, notes, trx_description, trx_to) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
                                                )
                                            ) {
                                                $stmt->bind_param(
                                                    'sssssssssssss',
                                                    $user_id,
                                                    $trx_amount,
                                                    $fee,
                                                    $fee_currency,
                                                    $currency,
                                                    $trx_sender,
                                                    $trx_hash,
                                                    $trx_ref,
                                                    $trx_type,
                                                    $trx_status,
                                                    $transaction_narration,
                                                    $trx_description,
                                                    $sent_narration
                                                );
                                                $stmt->execute();

                                                $sqlr = "SELECT * FROM users WHERE email= '$sent_email' ";
                                                $results = $link->query($sqlr);
                                                // output data of each row
                                                while (
                                                    $row = $results->fetch_assoc()
                                                ) {
                                                    $receiver_user_id =
                                                        $row['id'];
                                                }

                                                $trx_hash =
                                                    'TSF' .
                                                    substr(
                                                        str_shuffle(
                                                            $permitted_chars
                                                        ),
                                                        0,
                                                        65
                                                    );
                                                $trx_ref =
                                                    'ngn' .
                                                    substr(
                                                        str_shuffle(
                                                            $permitted_chars
                                                        ),
                                                        0,
                                                        12
                                                    );

                                                if (
                                                    $stmts = $link->prepare(
                                                        'INSERT INTO transactions (user_id, trx_amount, fee, fee_currency, currency, trx_sender, trx_hash, trx_ref, trx_type, trx_status, notes, trx_description, trx_to) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
                                                    )
                                                ) {
                                                    $stmts->bind_param(
                                                        'sssssssssssss',
                                                        $receiver_user_id,
                                                        $trx_amount,
                                                        $fee,
                                                        $fee_currency,
                                                        $currency,
                                                        $trx_sender,
                                                        $trx_hash,
                                                        $trx_ref,
                                                        $trx_type,
                                                        $trx_status,
                                                        $transaction_narration,
                                                        $trx_description,
                                                        $sent_narration
                                                    );
                                                    $stmts->execute();
                                                    header(
                                                        'location: success/transfer'
                                                    );
                                                    exit();
                                                } else {
                                                    // Something is wrong with the sql statement, check to make sure accounts table exists with all 3 fields.
                                                    $sent_respon =
                                                        '<div class="alert alert-danger text-center" role="alert">Could not prepare statement!</div>';
                                                }
                                            } else {
                                                // Something is wrong with the sql statement, check to make sure accounts table exists with all 3 fields.
                                                $sent_respon =
                                                    '<div class="alert alert-danger text-center" role="alert">Could not prepare statement!</div>';
                                            }
                                        }
                                    } else {
                                        // Something is wrong with the sql statement, check to make sure users table exists with all 3 fields.
                                        $sent_respon =
                                            '<div class="alert alert-danger text-center" role="alert">Could not prepare statement!</div>';
                                    }
                                }
                            } else {
                                $sent_respon =
                                    '<div class="alert alert-danger text-center" role="alert">Cannot sent youself funds</div>';
                            }
                        } else {
                            $sent_respon =
                                '<div class="alert alert-danger text-center" role="alert">Invalid Email Address</div>';
                        }
                    }
                }
            } else {
                $sent_respon =
                    '<div class="alert alert-danger text-center" role="alert">Please enter valid number amount.</div>';
            }
        } else {
            $sent_respon =
                '<div class="alert alert-danger text-center" role="alert">Please enter amount.div>';
        }
    } else {
        $sent_respon =
            '<div class="alert alert-danger text-center" role="alert">Please enter email.</div>';
    }
}
?>
