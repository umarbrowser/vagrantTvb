<?php

if (isset($email)) {
    // sent OTP email
}

?>
