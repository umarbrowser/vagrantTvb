<div class="header">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-xl-12">
                            <nav
                                class="
                                    navbar navbar-expand-lg navbar-light
                                    px-0
                                    justify-content-between
                                "
                            >
                                <a class="navbar-brand" href="index"
                                    ><img src="<?php echo $agpay_url; ?>/images/w_logo.png" alt="" />
                                    <span>Agpay</span></a
                                >

                                <div class="dashboard_log my-2">
                                    <div class="d-flex align-items-center">
                                        <div class="account_money">
                                            <ul>
                                                <li class="crypto">
                                                    <span>
                                                    <?php echo number_format(
                                                        $usd_price *
                                                            $ngn_balance,
                                                        2
                                                    ); ?> NGN
                                                    </span>
                                                </li>
                                                <li class="usd">
                                                    <span>
                                                        <?php echo number_format(
                                                            $ngn_price *
                                                                $ngn_balance,
                                                            2
                                                        ); ?> USD
                                                    </span>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="profile_log dropdown">
                                            <div class="user" data-toggle="dropdown">
                                                <span class="thumb"
                                                    ><i class="la la-user"></i
                                                ></span>
                                                <span class="name"><?php
                                                $arr1 = explode(
                                                    ' ',
                                                    trim($user_fullname)
                                                );
                                                echo htmlentities($arr1[0]);
                                                ?></span>
                                                <span class="arrow"
                                                    ><i class="la la-angle-down"></i
                                                ></span>
                                            </div>
                                            <div class="dropdown-menu dropdown-menu-right">
                                                <a href="<?php echo $agpay_url; ?>transactions" class="dropdown-item">
                                                    <i class="la la-list"></i> Transactions
                                                </a>
                                                <a href="<?php echo $agpay_url; ?>accounts" class="dropdown-item">
                                                    <i class="la la-user"></i> Account
                                                </a>
                                                <a href="<?php echo $agpay_url; ?>edit-profile" class="dropdown-item">
                                                    <i class="la la-cog"></i> Setting
                                                </a>
                                                <a
                                                    class="dropdown-item logout"
                                                    href="<?php echo $agpay_url; ?>logout"
                                                >
                                                    <i class="la la-sign-out"></i> Logout
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>