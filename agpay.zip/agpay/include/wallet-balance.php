<?php

// All User Information
$sql = "SELECT * FROM ngn WHERE user_id= '$userId' ";
$result = $link->query($sql);
// output data of each row
while ($row = $result->fetch_assoc()) {
    $ngn_balance = $row['balance'];
}
