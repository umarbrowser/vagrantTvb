<div class="sidebar">
                <div class="menu">
                    <ul>
                        <li>
                            <a
                                href="<?php echo $agpay_url; ?>"
                                data-toggle="tooltip"
                                data-placement="right"
                                title="Dashboard"
                                class="<?php if ($curPageName == 'index.php') {
                                    echo 'actived';
                                } ?>"
                            >
                                <span><i class="la la-igloo"></i></span>
                            </a>
                        </li>
                        <li>
                            <a
                                href="<?php echo $agpay_url; ?>wallet"
                                data-toggle="tooltip"
                                data-placement="right"
                                title="Wallet"
                                class="<?php if ($curPageName == 'wallet.php') {
                                    echo 'actived';
                                } ?>"
                                >
                                <span><i class="la la-wallet"></i></span>
                            </a>
                        </li>
                        <li>
                            <a
                                href="<?php echo $agpay_url; ?>swap"
                                data-toggle="tooltip"
                                data-placement="right"
                                title="Swap"
                                class="<?php if ($curPageName == 'swap.php') {
                                    echo 'actived';
                                } ?>"
                            >
                                <span><i class="fa fa-exchange"></i></span>
                            </a>
                        </li>
                        <li>
                            <a
                                href="<?php echo $agpay_url; ?>transfer"
                                data-toggle="tooltip"
                                data-placement="right"
                                title="Transfer"
                                class="<?php if (
                                    $curPageName == 'transfer.php'
                                ) {
                                    echo 'actived';
                                } ?>"
                            >
                                <span><i class="fa fa-send-o"></i></span>
                            </a>
                        </li>
                        <li>
                            <a
                                href="<?php echo $agpay_url; ?>accounts"
                                data-toggle="tooltip"
                                data-placement="right"
                                title="Account"
                                class="<?php if (
                                    $curPageName == 'accounts.php'
                                ) {
                                    echo 'actived';
                                } ?>"
                            >
                                <span><i class="la la-user"></i></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>