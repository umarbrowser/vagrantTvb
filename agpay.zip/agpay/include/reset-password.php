<?php

// Database connection
include 'dbcon.php';
$respon = '';

// Processing form data when form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['btn-reset'])) {
        $reset_email = $_POST['email'];
        // Validate credentials
        if (!empty($reset_email)) {
            // Prepare a select statement
            $sql = 'SELECT email, fullname FROM users WHERE email = ? ';

            if ($stmt = $link->prepare($sql)) {
                // Bind variables to the prepared statement as parameters
                $stmt->bind_param('s', $reset_email);

                // Attempt to execute the prepared statement
                if ($stmt->execute()) {
                    // Store result
                    $stmt->store_result();

                    // Check if email exists, if yes then verify password
                    if ($stmt->num_rows == 1) {
                        // Bind result variables
                        $stmt->bind_result($email, $fullname);

                        if ($stmt->fetch()) {
                            // Generate Reset Code
                            $permitted_chars =
                                '0123456789abcdefghijklmnopqrstuvwxyz';
                            $token = strtoupper(
                                substr(str_shuffle($permitted_chars), 0, 12)
                            );

                            $expFormat = mktime(
                                date('H'),
                                date('i'),
                                date('s'),
                                date('m'),
                                date('d') + 1,
                                date('Y')
                            );
                            $expDate = date('Y-m-d H:i:s', $expFormat);
                            $new_link = 'http://agpay.ng/reset-password/$token';

                            // Insert Temp Table
                            if (
                                $stmt = $link->prepare(
                                    'INSERT INTO password_resets (email, token, expDate) VALUES (?, ?, ?)'
                                )
                            ) {
                                $stmt->bind_param(
                                    'sss',
                                    $email,
                                    $token,
                                    $expDate
                                );
                                $stmt->execute();
                                //sent Email for User Activation
                                // User Full name, Email, Token Code
                                // include('include/activation-email.php');
                                $respon =
                                    '<div class="alert alert-success">An email has been sent to you with instructions on how to reset your password.</div>';
                            } else {
                                // Something is wrong with the sql statement, check to make sure accounts table exists with all 3 fields.
                                echo '<div class="alert alert-danger">Could not prepare statement!</div>';
                            }
                        }
                    } else {
                        $respon =
                            '<div class="alert alert-danger">No user is registered with this email address!</div>';
                    }
                }
            }
        } else {
            $respon =
                '<div class="alert alert-danger">Please field email form</div>';
        }
    }
}

?>
