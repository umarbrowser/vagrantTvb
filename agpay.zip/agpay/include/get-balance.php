<?php

// Get NGN User Infor
$sql = "SELECT * FROM ngn WHERE user_id= '$user_id' ";
$result = $link->query($sql);
// output data of each row
while ($row = $result->fetch_assoc()) {
    $ngn_balance = $row['balance'];
}

// Get AGK User Infor
$sql = "SELECT * FROM agk WHERE user_id= '$user_id' ";
$result = $link->query($sql);
// output data of each row
while ($row = $result->fetch_assoc()) {
    $agk_balance = $row['balance'];
}

$main_total_balance = $agk_balance;
