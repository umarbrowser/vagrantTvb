    <head>
        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Agpay Wallet - Dashboard</title>
        <link rel="stylesheet" href="<?php echo $agpay_url; ?>vendor/toastr/toastr.min.css">
        <link
            rel="shortcut icon"
            href="images/favicon.png"
            type="image/x-icon"
        />
        <?php if ($user_modeSwitcher == 2) {
            echo '<link rel="stylesheet" href="' .
                $agpay_url .
                'css/dark-style.css" />';
            echo '<meta name="theme-color" content="#3a3361">';
        } else {
            echo '<link rel="stylesheet" href="' .
                $agpay_url .
                'css/light-style.css" />';
            echo '<meta name="theme-color" content="#cbcbcb">';
        } ?>
    </head>