<?php
// Initialize the session
session_start();

// Check if the user is logged in, if not then redirect him to login page
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('location: login');
    exit();
}

$userId = $_SESSION['id'];

// Include Database Connection
require_once 'dbcon.php';

// App settings 192.168.0.181
$agpay_url = 'http://localhost/agpay/';
// $agpay_url = 'http://192.168.0.181/agpay/';

// All User Information
$sql = "SELECT * FROM users WHERE id= '$userId' ";
$result = $link->query($sql);
// output data of each row
while ($row = $result->fetch_assoc()) {
    $user_id = $row['id'];
    $user_email = $row['email'];
    $user_fullname = $row['fullname'];
    $user_base_currency = $row['base_currency'];
    $user_password = $row['password'];

    $user_activation_code = $row['activation_code'];
    $user_phonenumber = $row['phonenumber'];
    $user_profile = $row['profile'];
    $user_showBalance = $row['showBalance'];
    $user_modeSwitcher = $row['modeSwitcher'];

    $user_urlLink = $row['urlLink'];
    $user_username = $row['username'];
    $user_referral = $row['referral'];
    $user_pin = $row['pin'];
    $user_status = $row['status'];
}

// Initializing Naira Wallat
include 'initializing-wallet.php';

// Get any Prices
include 'currencies-prices.php';

// Get Balance
include 'get-balance.php';

if ($user_base_currency == 'NGN') {
    $user_base_price = $ngn_price;
} else {
    $user_base_price = $usd_price;
}

// Get any wallet balance
include 'wallet-balance.php';

// Get Page Name
$curPageName = substr(
    $_SERVER['SCRIPT_NAME'],
    strrpos($_SERVER['SCRIPT_NAME'], '/') + 1
);

?>
