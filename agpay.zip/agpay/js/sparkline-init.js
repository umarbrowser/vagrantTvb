(function ($) {

    $(".sparkline8").sparkline([79, 72, 29, 6, 52, 32, 73, 40, 14, 75, 77, 39, 9, 15, 10], {
        type: "line",
        width: "200px",
        height: "25",
        lineColor: "rgb(123, 111, 255)",
        fillColor: "rgba(123, 111, 255, .5)",
        minSpotColor: "rgb(123, 111, 255)",
        maxSpotColor: "rgb(123, 111, 255)",
        highlightLineColor: "rgb(123, 111, 255)",
        highlightSpotColor: "rgb(123, 111, 255)"
    });

})(jQuery);