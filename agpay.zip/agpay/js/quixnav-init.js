(function ($) {
    "use strict"

    new quixSettings({
        fontFamily: "nunito",
        bodybg: "color_1",
        navheaderBg: "color_1",

    });


})(jQuery);


