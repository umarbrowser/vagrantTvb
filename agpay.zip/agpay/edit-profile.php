<?php include 'include/session.php'; ?>
<!DOCTYPE html>
<html lang="en">
    
    <?php include 'include/head.php'; ?>

    <body>
        <div id="preloader">
            <div class="sk-three-bounce">
                <div class="sk-child sk-bounce1"></div>
                <div class="sk-child sk-bounce2"></div>
                <div class="sk-child sk-bounce3"></div>
            </div>
        </div>
        

        <!-- Include Header -->
        <?php include 'include/header.php'; ?>
        <!-- Include Menu -->
        <?php include 'include/menu.php'; ?>
        <!-- Include Page Title -->
        <?php include 'include/page_title.php'; ?>
        <div class="content-body">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xl-3 col-md-4">
                        <?php include 'include/settings-menu.php'; ?>
                    </div>
                    <div class="col-xl-8">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Personal Information</h4>
                            </div>
                            <div class="card-body">
                                <form onsubmit="event.preventDefault();" name="myform" class="personal_validate">
                                    <div class="form-row">
                                        <div class="form-group col-xl-6">
                                            <label class="mr-sm-2">Full Name</label>
                                            <input type="text" class="form-control" placeholder="" value="<?php echo htmlentities(
                                                $user_fullname
                                            ); ?>" name="fullname">
                                        </div>
                                        <div class="form-group col-xl-6">
                                            <label class="mr-sm-2">Email</label>
                                            <input type="email" class="form-control" value="<?php echo htmlentities(
                                                $user_email
                                            ); ?>"
                                            style="background: #312b53;"
                                                placeholder="Hello@example.com" name="" disabled>
                                        </div>
                                        <div class="form-group col-xl-6">
                                            <label class="mr-sm-2">Date of birth</label>
                                            <input type="text" class="form-control" placeholder="10-10-2020"
                                                id="datepicker" autocomplete="off" name="dob">
                                        </div>
                                        <div class="form-group col-xl-6">
                                            <label class="mr-sm-2">Present Address</label>
                                            <input type="text" class="form-control"
                                                placeholder="56, Old Street, Brooklyn" name="presentaddress">
                                        </div>
                                        <div class="form-group col-xl-6">
                                            <label class="mr-sm-2">Permanent Address</label>
                                            <input type="text" class="form-control"
                                                placeholder="123, Central Square, Brooklyn"
                                                name="permanentaddress">
                                        </div>
                                        <div class="form-group col-xl-6">
                                            <label class="mr-sm-2">City</label>
                                            <input type="text" class="form-control" placeholder="New York"
                                                name="city">
                                        </div>
                                        <div class="form-group col-xl-6">
                                            <label class="mr-sm-2">Postal Code</label>
                                            <input type="text" class="form-control" placeholder="25481"
                                                name="postal">
                                        </div>
                                        <div class="form-group col-xl-6">
                                            <label class="mr-sm-2">Country</label>
                                            <select class="form-control" name="country">
                                                
                                                <option value="Zimbabwe">Zimbabwe<option>
                                            </select>
                                        </div>

                                        <div class="form-group col-12">
                                            <button class="btn btn-success pl-5 pr-5">Save</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src="vendor/jquery/jquery.min.js"></script>
        <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="vendor/waves/waves.min.js"></script>
        <script src="vendor/validator/jquery.validate.js"></script>
        <script src="vendor/validator/validator-init.js"></script>
        <script src="vendor/scrollit/scrollIt.js"></script>
        <script src="js/plugins/scrollit-init.js"></script>
        <script src="js/scripts.js"></script>
        <script src="js/settings.js"></script>
        <script src="js/quixnav-init.js"></script>
        <script src="js/styleSwitcher.js"></script>
       <script src="vendor/jquery-ui/jquery-ui.min.js"></script>
      <script src="js/plugins/jquery-ui-init.js"></script>
    </body>
</html>
