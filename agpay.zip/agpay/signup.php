<?php
require_once 'include/csrf-67h38ey-token.php';
use csrfhandler\csrf as csrf;
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Agpay Wallet - Sign up</title>
    <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon" />
    <link rel="stylesheet" href="css/dark-style.css" />
    <?php
//if ($time == 2) {
//echo '<link rel="stylesheet" href="css/dark-style.css" />';
//} else {
//  echo '<link rel="stylesheet" href="css/light-style.css" />';
//}
?>
    <script src="https://www.google.com/recaptcha/api.js?render=6LemGz8eAAAAAFw06b_CHCcGnT5o59Sgs57vHXyW"></script>
  </head>
  
  <body>
    <div id="preloader">
      <div class="sk-three-bounce">
        <div class="sk-child sk-bounce1"></div>
        <div class="sk-child sk-bounce2"></div>
        <div class="sk-child sk-bounce3"></div>
      </div>
    </div>
    <div id="main-wrapper">
      <div class="authincation section-padding">
        <div class="container h-100">
          <div class="row justify-content-center h-100 align-items-center">
            <div class="col-xl-5 col-md-6">
              <div class="mini-logo text-center my-5">
                <img src="./images/m_logo.png" alt="" />
              </div>
              <div class="auth-form card">
                <div class="card-header justify-content-center">
                  <h4 class="card-title">Sign up your account</h4>
                </div>
                <div class="card-body">
                  <form
                    name="myform"
                    action=""
                    method="post"
                    class="signup_validate"
                  >
                    <input type="hidden" name="recaptcha_response" value="" id="recaptchaResponse">
                    <input type="hidden" name="_token" value="<?php echo csrf::token(); ?>">
                    <div class="form-group">
                        <?php include 'include/signup_process.php'; ?>
                    </div>
                    <div class="form-group">
                      <label>Full Name</label>
                      <input
                        type="text"
                        class="form-control"
                        placeholder="Enter your full name"
                        name="fullname"
                      />
                      <span class="text-danger"></span>
                    </div>
                    <div class="form-group">
                      <label>Email</label>
                      <input
                        type="email"
                        class="form-control"
                        placeholder="hello@example.com"
                        name="email"
                      />
                      <span id="lblError" class="text-danger"></span>
                    </div>
                    <div class="form-group">
                      <label>Password</label>
                      <input
                        type="password"
                        class="form-control"
                        placeholder="Password"
                        name="password"
                        id="password"
                      />
                      <span class="text-danger"></span>
                    </div>
                    
                    <div class="text-center mt-4">
                      <button type="submit" name="btn-signup" id="btn-submit" class="btn btn-success btn-block">
                        Sign up
                      </button>
                    </div>
                  </form>
                  <div class="new-account mt-3">
                    <p>
                      Already have an account?
                      <a class="text-primary" href="login">
                        Sign in
                      </a>
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/waves/waves.min.js"></script>
    <script src="vendor/validator/jquery.validate.js"></script>
    <script src="vendor/validator/validator-init.js"></script>
    <script src="vendor/scrollit/scrollIt.js"></script>
    <script src="js/plugins/scrollit-init.js"></script>
    <script src="js/scripts.js"></script>
    <script src="js/settings.js"></script>
    <script src="js/quixnav-init.js"></script>
    <script src="js/styleSwitcher.js"></script>
    <script>
        grecaptcha.ready(function(){
            grecaptcha.execute('6LemGz8eAAAAAFw06b_CHCcGnT5o59Sgs57vHXyW', { action:'submit'}).then(function (token){
                var recaptchaResponse=document.getElementById('recaptchaResponse');
                recaptchaResponse.value=token;
            })
        })
    </script>
  </body>
</html>
