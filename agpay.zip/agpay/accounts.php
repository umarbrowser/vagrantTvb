<?php include 'include/session.php'; ?>
<!DOCTYPE html>
<html lang="en">
  
  <?php include 'include/head.php'; ?>

  <body>
    <div id="preloader">
      <div class="sk-three-bounce">
        <div class="sk-child sk-bounce1"></div>
        <div class="sk-child sk-bounce2"></div>
        <div class="sk-child sk-bounce3"></div>
      </div>
    </div>
    <div id="main-wrapper">
      <!-- Include Header -->
      <?php include 'include/header.php'; ?>
      <!-- Include Menu -->
      <?php include 'include/menu.php'; ?>
      <br><br><br><br>
      <div class="content-body">
        <div class="container-fluid">
          <div class="row">
            <div class="col-xl-2 col-md-2"></div>
            <div class="col-xl-3 col-md-4"><br>
                <?php include 'include/settings-menu.php'; ?>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-6">
              <div class="card profile_card">
                <div class="card-body">
                  <div class="media">
                    <img
                      class="mr-3 rounded-circle mr-0 mr-sm-3"
                      src="uploads/<?php echo htmlentities($user_profile); ?>"
                      width="60"
                      height="60"
                      alt=""
                    />
                    <div class="media-body">
                      <h4 class="mb-2"><?php echo htmlentities(
                          $user_fullname
                      ); ?></h4>
                      <p class="mb-1">
                        <span>
                          <i class="fa fa-envelope mr-2 text-primary"></i>
                        </span>
                        <span class="text-muted">
                          <?php echo htmlentities($user_email); ?>
                        </span>
                        <span style=" background: #10d876; color: #fff; padding: 10px; border-radius: 50px; height: 20px; width: 20px; justify-content: center; align-items: center; padding: 3px; margin-right: 15px; font-weight: bold; font-size: 12px; "><i class="la la-check"></i></span>
                      </p>
                    </div>
                  </div>

                  <ul class="card-profile__info">
                    <li>
                      <h5 class="mr-4">Address</h5>
                      <span class="text-muted">
                        House 14, Road 9, Gulshan, Dhaka
                      </span>
                    </li>
                    <li class="mb-1">
                      <h5 class="mr-4">Total Log</h5>
                      <span class="text-muted">103 Time (Today 5 Times)</span>
                    </li>
                    <li>
                      <h5 class="text-danger mr-4">Last Log</h5>
                      <span class="text-danger">
                        3 February, 2020, 10:00 PM
                      </span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <?php include 'include/footer.php'; ?>
      
    </div>
    <script
      data-cfasync="false"
      src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"
    ></script>
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/waves/waves.min.js"></script>
    <script src="vendor/validator/jquery.validate.js"></script>
    <script src="vendor/validator/validator-init.js"></script>
    <script src="vendor/scrollit/scrollIt.js"></script>
    <script src="js/plugins/scrollit-init.js"></script>
    <script src="js/scripts.js"></script>
    <script src="js/settings.js"></script>
    <script src="js/quixnav-init.js"></script>
    <script src="js/styleSwitcher.js"></script>
  </body>
</html>
