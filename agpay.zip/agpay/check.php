<?php
include_once 'include/session.php';

if (isset($_POST['user_name']) && $_POST['user_name'] != '') {
    $response = [];
    $username = mysqli_real_escape_string($link, $_POST['user_name']);
    $sql =
        "SELECT email, fullname FROM users WHERE users.email='" .
        $username .
        "'";
    $res = $link->query($sql);

    if ($res->num_rows > 0) {
        while ($row = $res->fetch_assoc()) {
            $fullname = $row['fullname'];
        }
        $response['status'] = false;
        $response['msg'] =
            '<div class="alert alert-success" role="alert"><h4 class="alert-heading">' .
            htmlentities($fullname) .
            '</h4><hr><p>Ensure that the name of the recipient is corrent as transfer are not <b>reversible</b></p></div>';
    } else {
        $response['status'] = true;
        $response['msg'] =
            '<div class="alert alert-danger" role="alert">This email address is not exists.</div>';
    }
    echo json_encode($response);
}
