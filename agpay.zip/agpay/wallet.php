<?php include 'include/session.php'; ?>
<!DOCTYPE html>
<html lang="en">
        
    <?php include 'include/head.php'; ?>

    <body>
        <div id="preloader">
            <div class="sk-three-bounce">
                <div class="sk-child sk-bounce1"></div>
                <div class="sk-child sk-bounce2"></div>
                <div class="sk-child sk-bounce3"></div>
            </div>
        </div>
        <div id="main-wrapper">
            <!-- Include Header -->
            <?php include 'include/header.php'; ?>
            <!-- Include Menu -->
            <?php include 'include/menu.php'; ?>
            <br><br>
            <div class="content-body">
                <div class="container-fluid">
                      <div class="row justify-content-center h-100 align-items-center">
                        <div class="col-xl-4 col-lg-4 col-xxl-4">
                            <div class="card balance-widget">
                                <div class="card-body pt-0">
                                    <div class="balance-widget">
                                        <div class="total-balance">
                                            <h3>
                                            <?php if (
                                                $user_base_currency == 'NGN'
                                            ) {
                                                echo number_format(
                                                    $user_base_price *
                                                        $ngn_balance,
                                                    2
                                                );
                                            } else {
                                                echo number_format(
                                                    $user_base_price *
                                                        $ngn_balance,
                                                    2
                                                );
                                            } ?>
                                            </h3>
                                            <h6>Total Balance</h6>
                                        </div>
                                        <ul class="list-unstyled">
                                            <li class="media">
                                                <i class="cc BTC mr-3"></i>
                                                <div class="media-body">
                                                    <h5 class="m-0">Naira</h6>
                                                <span><?php echo number_format(
                                                    $ngn_price,
                                                    4
                                                ); ?> USD</span>
                                                </div>
                                                <div class="text-right">
                                                    <h5 class="m-0"><?php echo number_format(
                                                        $ngn_balance,
                                                        2
                                                    ); ?> <?php echo $ngn_symbol; ?></h5>
                                                    <span><b><?php echo number_format(
                                                        $ngn_price *
                                                            $ngn_balance,
                                                        2
                                                    ); ?> USD</b></span>
                                                </div>
                                            </li>
                                            
                                        </ul>
                                        <ul class="list-unstyled">
                                            <li class="media">
                                                <i class="cc BTC mr-3"></i>
                                                <div class="media-body">
                                                    <h5 class="m-0">Agrikoin</h6>
                                                <span><?php echo number_format(
                                                    $agk_price,
                                                    4
                                                ); ?> USD</span>
                                                </div>
                                                <div class="text-right">
                                                    <h5 class="m-0"><?php echo number_format(
                                                        $agk_balance,
                                                        2
                                                    ); ?> <?php echo $agk_symbol; ?></h5>
                                                    <span><b><?php if (
                                                        $user_base_currency ==
                                                        'USD'
                                                    ) {
                                                        echo number_format(
                                                            $agk_price *
                                                                $agk_balance,
                                                            4
                                                        ) . ' USD';
                                                    } else {
                                                        echo $agk_price *
                                                            $agk_balance *
                                                            $ngn_price;
                                                    } ?> </b></span>
                                                </div> 
                                            </li>
                                            
                                        </ul>
                                    </div>
                                </div>
                            </div>
                          </div>
                    </div>
                </div>
            </div>

        </div>
        <script src="vendor/jquery/jquery.min.js"></script>
        <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="vendor/waves/waves.min.js"></script>
        <script src="vendor/validator/jquery.validate.js"></script>
        <script src="vendor/validator/validator-init.js"></script>
        <script src="vendor/scrollit/scrollIt.js"></script>
        <script src="js/plugins/scrollit-init.js"></script>
        <script src="js/scripts.js"></script>
        <script src="js/settings.js"></script>
        <script src="js/quixnav-init.js"></script>
        <script src="js/styleSwitcher.js"></script>
        <script src="vendor/circle-progress/circle-progress.min.js"></script>
        <script src="vendor/circle-progress/circle-progress-init.js"></script>
        <script src="vendor/apexchart/apexcharts.min.js"></script>
        <script src="vendor/apexchart/apexchart-init.js"></script>
    </body>
</html>
