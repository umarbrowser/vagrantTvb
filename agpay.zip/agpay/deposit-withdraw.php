<?php include 'include/session.php'; ?>
<!DOCTYPE html>
<html lang="en">
  
  <?php include 'include/head.php'; ?>

  <body>
    <div id="preloader">
      <div class="sk-three-bounce">
        <div class="sk-child sk-bounce1"></div>
        <div class="sk-child sk-bounce2"></div>
        <div class="sk-child sk-bounce3"></div>
      </div>
    </div>
    <div id="main-wrapper">
      <!-- Include Header -->
      <?php include 'include/header.php'; ?>
      <!-- Include Menu -->
      <?php include 'include/menu.php'; ?>
      <!-- Include Page Title -->
      <?php include 'include/page_title.php'; ?>
      
      <div class="content-body">
        <div class="container-fluid">
          <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12">
              <div class="row justify-content-center h-100 align-items-center">
                <div class="col-xl-5 col-md-6">
                  <div class="auth-form card">
                    <div class="card-body">
                        <div class="buy-sell-widget" id="deposit-withdraw">
                          <ul class="nav nav-tabs">
                            <li class="nav-item">
                              <a
                                class="nav-link active"
                                data-toggle="tab"
                                href="#deposit"
                                style="font-size: 13px"
                              >
                                Deposit
                              </a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link" data-toggle="tab" href="#withdraw" style="font-size: 13px">
                                Withdraw
                              </a>
                            </li>
                          </ul>
                          <div class="tab-content tab-content-default">
                            <div
                              class="tab-pane fade show active"
                              id="deposit"
                              role="tabpanel"
                            >
                              <form
                                action="deposit"
                                method="POST"
                                name="myform"
                                class="currency_validate"
                              >
                                <div class="form-group">
                                  <label class="mr-sm-2">Amount (NGN)</label>
                                  <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                      <label class="input-group-text">
                                        <i class="cc BTC-alt"></i>
                                      </label>
                                    </div>
                                    <input type="number" name="depositAmount" class="form-control">
                                  </div>
                                </div>

                                <div class="form-group">
                                  <label class="mr-sm-2">Payment Method</label>
                                  <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                      <label class="input-group-text">
                                        <i class="fa fa-bank"></i>
                                      </label>
                                    </div>
                                    <select id="deposit-method" name="depositMethod" class="form-control">
                                      <option value=""> Select </option>
                                      <option value="mobile-wallet">Mobile Wallet</option>
                                      <option value="bank-tranfer" disabled>Bank Tranfer</option>
                                    </select>
                                  </div>
                                </div>

                                <div id="mobile-wallet-container" style="display: none;">
                                  <div class="form-group">
                                    <label class="mr-sm-2">Wallet Name</label>
                                    <div class="input-group mb-3">
                                      <div class="input-group-prepend">
                                        <label class="input-group-text">
                                          <i class="la la-wallet"></i>
                                        </label>
                                      </div>
                                      <select class="form-control" name="depositWalletOption">
                                        <option value=""> Select </option>
                                        <option value="deposit-reven">Revan</option>
                                        <option value="deposit-kuda">Kuda</option>
                                      </select>
                                    </div>
                                  </div>
                                  <button
                                    type="submit"
                                    name="deposit-ngn"
                                    class="btn btn-primary btn-block"
                                  >
                                    Next
                                  </button>
                                </div>
                                <div id="bank-tranfer-container" style="display: none;">
                                  <!-- Bank Tranfer information -->
                                </div>

                              </form>
                            </div>
                            <div class="tab-pane fade" id="withdraw">
                              <form
                                action="withdraw"
                                method="post"
                                name="myform"
                                class="currency2_validate"
                              >
                                <div class="form-group">
                                  <label class="mr-sm-2">Amount (NGN)</label>
                                  <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                      <label class="input-group-text">
                                        <i class="cc BTC-alt"></i>
                                      </label>
                                    </div>
                                    <input type="number" name="withdrawAmount" class="form-control">
                                  </div>
                                </div>

                                <div class="form-group">
                                  <label class="mr-sm-2">Payment Method</label>
                                  <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                      <label class="input-group-text">
                                        <i class="fa fa-bank"></i>
                                      </label>
                                    </div>
                                    <select id="withdraw-method" name="withdrawMethod" class="form-control">
                                      <option value=""> Select </option>
                                      <option value="mobile-wallet">Mobile Wallet</option>
                                      <option value="bank-tranfer" disabled>Bank Tranfer</option>
                                    </select>
                                  </div>
                                </div>

                                <div id="mobile-wallet-container-withdraw" style="display: none;">
                                  <div class="form-group">
                                    <label class="mr-sm-2">Wallet Name</label>
                                    <div class="input-group mb-3">
                                      <div class="input-group-prepend">
                                        <label class="input-group-text">
                                          <i class="la la-wallet"></i>
                                        </label>
                                      </div>
                                      <select class="form-control" name="withdrawWalletOption">
                                        <option value=""> Select </option>
                                        <option value="withdraw-reven">Revan</option>
                                        <option value="withdraw-kuda">Kuda</option>
                                      </select>
                                    </div>
                                  </div>
                                  <button
                                    type="submit"
                                    name="withdraw-ngn"
                                    class="btn btn-primary btn-block"
                                  >
                                    Next
                                  </button>
                                </div>
                              </form>
                            </div>
                            <p class="p-2 text-danger">
                              Note: Lorem ipsum dolor sit amet consectetur adipisicing elit.
                              Modi cupiditate suscipit explicabo voluptas eos in tenetur error
                              temporibus dolorum. Nulla!
                            </p>
                          </div>
                        </div>
                </div>
            </div>
              
          </div>

        </div>
      </div>
    </div>
    <script
      data-cfasync="false"
      src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"
    ></script>
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/waves/waves.min.js"></script>
    <script src="vendor/validator/jquery.validate.js"></script>
    <script src="vendor/validator/validator-init.js"></script>
    <script src="vendor/scrollit/scrollIt.js"></script>
    <script src="js/plugins/scrollit-init.js"></script>
    <script src="js/scripts.js"></script>
    <script src="js/settings.js"></script>
    <script src="js/quixnav-init.js"></script>
    <script src="js/styleSwitcher.js"></script>
    <script src="vendor/magnific-popup/magnific-popup.js"></script>
    <script src="vendor/magnific-popup/magnific-popup-init.js"></script>
    <script src="vendor/validator/jquery.validate.js"></script>
    <script src="vendor/validator/validator-init.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script>
      $(document).ready(function(){
          $("#deposit-method").change(function(){
              $(this).find("option:selected").each(function(){
                  var optionValue = $(this).attr("value");
                  if(optionValue == "mobile-wallet"){
                      $("#mobile-wallet-container").show();
                      $("#bank-tranfer-container").hide();
                  }else if(optionValue == "bank-tranfer"){
                      $("#mobile-wallet-container").hide();
                      $("#bank-tranfer-container").show();
                  } else{
                      $(".box").hide();
                  }
              });
          }).change();
      });
    </script>
    <script>
      $(document).ready(function(){
          $("#withdraw-method").change(function(){
              $(this).find("option:selected").each(function(){
                  var optionValue = $(this).attr("value");
                  if(optionValue == "mobile-wallet"){
                      $("#mobile-wallet-container-withdraw").show();
                      $("#bank-tranfer-container-withdraw").hide();
                  }else if(optionValue == "bank-tranfer"){
                      $("#mobile-wallet-container-withdraw").hide();
                      $("#bank-tranfer-container-withdraw").show();
                  } else{
                      $(".box").hide();
                  }
              });
          }).change();
      });
    </script>
  </body>
</html>