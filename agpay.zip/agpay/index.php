<?php include 'include/session.php'; ?>
<!DOCTYPE html>
<html lang="en">
    
    <?php include 'include/head.php'; ?>

    <body>
        <div id="preloader">
            <div class="sk-three-bounce">
                <div class="sk-child sk-bounce1"></div>
                <div class="sk-child sk-bounce2"></div>
                <div class="sk-child sk-bounce3"></div>
            </div>
        </div>
        <div id="main-wrapper">
            <!-- Include Header -->
            <?php include 'include/header.php'; ?>
            <!-- Include Menu -->
            <?php include 'include/menu.php'; ?>
            <!-- Include Page Title -->
            <?php include 'include/page_title.php'; ?>
            <div class="content-body">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-xl-3 col-lg-4 col-xxl-4">
                            <div class="card balance-widget">
                                <div class="card-header border-0 py-0">
                                    <h4 class="card-title">Your Portfolio </h4>
                                </div>
                                <div class="card-body pt-0">
                                    <div class="balance-widget">
                                        <div class="total-balance">
                                            <h3>$63411.00</h3>
                                            <h6>Total Balance</h6>
                                        </div>
                                        <ul class="list-unstyled">
                                            <li class="media">
                                                <i class="cc BTC mr-3"></i>
                                                <div class="media-body">
                                                    <h5 class="m-0">Bitcoin</h6>
                                                </div>
                                                <div class="text-right">
                                                    <h5>0.000242 BTC</h5>
                                                    <span>0.125 USD</span>
                                                </div>
                                            </li>
                                            <li class="media">
                                                <i class="cc LTC mr-3"></i>
                                                <div class="media-body">
                                                    <h5 class="m-0">Litecoin</h6>
                                                </div>
                                                <div class="text-right">
                                                    <h5>0.000242 LTC</h5>
                                                    <span>0.125 USD</span>
                                                </div>
                                            </li>
                                            <li class="media">
                                                <i class="cc XRP mr-3"></i>
                                                <div class="media-body">
                                                    <h5 class="m-0">Ripple</h6>
                                                </div>
                                                <div class="text-right">
                                                    <h5>0.000242 XRP</h5>
                                                    <span>0.125 USD</span>
                                                </div>
                                            </li>
                                            <li class="media">
                                                <i class="cc DASH mr-3"></i>
                                                <div class="media-body">
                                                    <h5 class="m-0">Dash</h6>
                                                </div>
                                                <div class="text-right">
                                                    <h5>0.000242 XRP</h5>
                                                    <span>0.125 USD</span>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-6 col-lg-8 col-xxl-8">
                            <div class="card profile_chart">
                                <div class="card-header py-0">
                                    <div class="chart_current_data">
                                        <h3>254856 <span>USD</span></h3>
                                        <p class="text-success">125648 <span>USD (20%)</span></p>
                                    </div>
                                    <div class="duration-option">
                                    <a id="all" class="active">ALL</a>
                                </div>
                                </div>
                                <div class="card-body">
                                    <div id="timeline-chart"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-12 col-xxl-12">
                            <div class="card">
                                <div class="card-header border-0 py-0">
                                    <h4 class="card-title">Follow</h4>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-xl-12 col-lg-6 col-xxl-6">
                                            <div class="widget-card">
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <div class="widget-stat">
                                                        <div class="coin-title">
                                                            <span><i class="cc BTC-alt"></i></span>
                                                            <h5 class="d-inline-block ml-2 mb-3">Bitcoin <span>(24h)</span>
                                                            </h5>
                                                        </div>
                                                        <h4>USD 1254.36 <span class="badge badge-success ml-2">+ 06%</span>
                                                        </h4>
                                                    </div>
                                                    <div id="btcChart"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-12 col-lg-6 col-xxl-6">
                                            <div class="widget-card">
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <div class="widget-stat">
                                                        <div class="coin-title">
                                                            <span><i class="cc ETH-alt"></i></span>
                                                            <h5 class="d-inline-block ml-2 mb-3">Ethereum <span>(24h)</span>
                                                            </h5>
                                                        </div>
                                                        <h4>USD 1254.36 <span class="badge badge-danger ml-2">- 06%</span>
                                                        </h4>
                                                    </div>
                                                    <div id="ltcChart"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-12 col-lg-6 col-xxl-6">
                                            <div class="widget-card">
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <div class="widget-stat">
                                                        <div class="coin-title">
                                                            <span><i class="cc LTC-alt"></i></span>
                                                            <h5 class="d-inline-block ml-2 mb-3">Litecoin <span>(24h)</span>
                                                            </h5>
                                                        </div>
                                                        <h4>USD 1254.36 <span class="badge badge-primary ml-2"> 06%</span>
                                                        </h4>
                                                    </div>
                                                    <div id="xrpChart"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-12 col-lg-6 col-xxl-6">
                                            <div class="widget-card">
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <div class="widget-stat">
                                                        <div class="coin-title">
                                                            <span><i class="cc XRP-alt"></i></span>
                                                            <h5 class="d-inline-block ml-2 mb-3">Ripple <span>(24h)</span>
                                                            </h5>
                                                        </div>
                                                        <h4>USD 1254.36 <span class="badge badge-danger ml-2">- 06%</span>
                                                        </h4>
                                                    </div>
                                                    <div id="dashChart"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <script src="vendor/jquery/jquery.min.js"></script>
        <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="vendor/waves/waves.min.js"></script>
        <script src="vendor/validator/jquery.validate.js"></script>
        <script src="vendor/validator/validator-init.js"></script>
        <script src="vendor/scrollit/scrollIt.js"></script>
        <script src="js/plugins/scrollit-init.js"></script>
        <script src="js/scripts.js"></script>
        <script src="js/settings.js"></script>
        <script src="js/quixnav-init.js"></script>
        <script src="js/styleSwitcher.js"></script>
        <script src="vendor/circle-progress/circle-progress.min.js"></script>
        <script src="vendor/circle-progress/circle-progress-init.js"></script>
        <script src="vendor/apexchart/apexcharts.min.js"></script>
        <script src="vendor/apexchart/apexchart-init.js"></script>
    </body>
</html>
