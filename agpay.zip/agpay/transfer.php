<?php include 'include/session.php'; ?>
<?php include 'include/sent-process.php'; ?>
<!DOCTYPE html>
<html lang="en">
  
  <?php include 'include/head.php'; ?>

  <body>
    <div id="preloader">
      <div class="sk-three-bounce">
        <div class="sk-child sk-bounce1"></div>
        <div class="sk-child sk-bounce2"></div>
        <div class="sk-child sk-bounce3"></div>
      </div>
    </div>
    <div id="main-wrapper">
      <!-- Include Header -->
      <?php include 'include/header.php'; ?>
      <!-- Include Menu -->
      <?php include 'include/menu.php'; ?>
      <br><br><br><br>
      
      <div class="content-body">
        <div class="container-fluid">
          <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12">
              <div class="row justify-content-center h-100 align-items-center">
                <div class="col-xl-5 col-md-6">
                  <div class="auth-form card">
                    <div class="card-body">
                        <div class="buy-sell-widget">
                          <ul class="nav nav-tabs">
                            <li class="nav-item">
                              <a
                                class="nav-link active"
                                data-toggle="tab"
                                href="#send"
                                style="font-size: 13px"
                              >
                                Send
                              </a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link" data-toggle="tab" href="#receive" style="font-size: 13px">
                                Receive
                              </a>
                            </li>
                          </ul>
                          <div class="tab-content tab-content-default">
                            <div
                              class="tab-pane fade show active"
                              id="send"
                              role="tabpanel"
                            >
                              <form
                                action=""
                                method="POST"
                                name="myform"
                                class="currency_validate"
                              >
                              <?php
                              if ($sent_status == 'success') {
                                  echo '<div class="alert alert-success text-center" role="alert">Transfer was successfully sent.</div>';
                              }
                              echo $sent_respon;
                              ?>
                                <div class="form-group">
                                  <label class="mr-sm-2">Amount (NGN)</label>
                                  <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                      <label class="input-group-text">
                                        <i class="fa fa-money"></i>
                                      </label>
                                    </div>
                                    <input type="number" name="amount" class="form-control" required>
                                  </div>
                                </div>
                                <div class="form-group">
                                  <label class="mr-sm-2">Email Address</label>
                                  <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                      <label class="input-group-text">
                                        <i class="fa fa-envelope"></i>
                                      </label>
                                    </div>
                                    <input type="email" id="email" name="email" class="form-control" required>
                                  </div>
                                  <span id="usercheck" class="help-block"></span>
                                </div>
                                <div class="form-group">
                                  <label class="mr-sm-2">Sent Narration (optional)</label>
                                  <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                      <label class="input-group-text">
                                        <i class="fa fa-list-alt"></i>
                                      </label>
                                    </div>
                                    <input type="text" name="sent_narration" class="form-control">
                                  </div>
                                </div>
                                  
                                  <button
                                    type="submit"
                                    name="sentngn"
                                    class="btn btn-primary btn-block"
                                  >
                                    Next
                                  </button>
                                <div id="bank-tranfer-container" style="display: none;">
                                  <!-- Bank Tranfer information -->
                                </div>

                              </form>
                            </div>
                            <div class="tab-pane fade" id="receive">
                              QR Code
                            </div>
                            <p class="p-2 text-danger">
                              Note: Lorem ipsum dolor sit amet consectetur adipisicing elit.
                              Modi cupiditate suscipit explicabo voluptas eos in tenetur error
                              temporibus dolorum. Nulla!
                            </p>
                          </div>
                        </div>
                </div>
            </div>
              
          </div>

        </div>
      </div>
    </div>
    <script
      data-cfasync="false"
      src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"
    ></script>
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/waves/waves.min.js"></script>
    <script src="vendor/validator/jquery.validate.js"></script>
    <script src="vendor/validator/validator-init.js"></script>
    <script src="vendor/scrollit/scrollIt.js"></script>
    <script src="js/plugins/scrollit-init.js"></script>
    <script src="js/scripts.js"></script>
    <script src="js/settings.js"></script>
    <script src="js/quixnav-init.js"></script>
    <script src="js/styleSwitcher.js"></script>
    <script src="vendor/magnific-popup/magnific-popup.js"></script>
    <script src="vendor/magnific-popup/magnific-popup-init.js"></script>
    <script src="vendor/validator/jquery.validate.js"></script>
    <script src="vendor/validator/validator-init.js"></script>
    <script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-2.0.3.js"></script>
    <script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
    <script type="text/javascript">
    $(document).ready(function(){
      $('#email').change(function() {
      var usercheck = $(this).val();
            $('#usercheck').html('<img src="images/loading.gif" width="30" />');
          $.post("check.php", {user_name: usercheck} , function(data)
          {
          if (data.status == true)
          {
          $('#usercheck').parent('div').removeClass('has-error').addClass('has-success');
          
          } else {
          $('#usercheck').parent('div').removeClass('has-success').addClass('has-error');
          }
          $('#usercheck').html(data.msg);
          },'json');
      });
    });
    </script>
  </body>
</html>