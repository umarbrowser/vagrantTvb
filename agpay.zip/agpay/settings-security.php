<?php include 'include/session.php'; ?>
<!DOCTYPE html>
<html lang="en">
  
  <?php include 'include/head.php'; ?>

  <body>
    <div id="preloader">
      <div class="sk-three-bounce">
        <div class="sk-child sk-bounce1"></div>
        <div class="sk-child sk-bounce2"></div>
        <div class="sk-child sk-bounce3"></div>
      </div>
    </div>
    <div id="main-wrapper">
        <!-- Include Header -->
        <?php include 'include/header.php'; ?>
        <!-- Include Menu -->
        <?php include 'include/menu.php'; ?>
        <!-- Include Page Title -->
        <?php include 'include/page_title.php'; ?>

      <div class="content-body">
        <div class="container-fluid">
          <div class="row">
            <div class="col-xl-3 col-md-4">
              <?php include 'include/settings-menu.php'; ?>
            </div>
            <div class="col-xl-9 col-md-8">
              <div class="card">
                <div class="card-header">
                  <h4 class="card-title">Security</h4>
                </div>
                <div class="card-body">

                  <div class="row">
                    <div class="col-xl-12">
                      <div class="phone_verify">
                        <h4 class="card-title mb-3">Email Address</h4>
                        <form action="otp-2">
                          <div class="form-row align-items-center">
                            <div class="form-group col-xl-6">
                              <input
                                type="text"
                                class="form-control"
                                placeholder="hello@example.com "
                              />
                              <button class="btn btn-success mt-4">
                                Add
                              </button>
                            </div>
                          </div>
                        </form>
                      </div>
                    </div>
                    <div class="col-xl-12">
                      <div class="phone_verified">
                        <h5>
                          <span><i class="fa fa-envelope"></i></span>
                          <a
                            href="/cdn-cgi/l/email-protection"
                            class="__cf_email__"
                            data-cfemail="59313c353536193c21383429353c773a3634"
                          >
                            [email&#160;protected]
                          </a>
                        </h5>
                        <div class="verify">
                          <div class="verified">
                            <span><i class="la la-check"></i></span>
                            <a href="javascript:void(0)">Verified</a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-xl-12">
                      <div class="phone_verify">
                        <h4 class="card-title mb-3">Add Phone Number</h4>
                        <form action="otp-2">
                          <div class="form-row align-items-center">
                            <div class="form-group col-xl-6">
                              <input
                                type="text"
                                class="form-control"
                                placeholder="+1 2335 2458 "
                              />
                              <button class="btn btn-success mt-4">
                                Add
                              </button>
                            </div>
                          </div>
                        </form>
                      </div>
                    </div>
                    <div class="col-xl-12">
                      <div class="phone_verified">
                        <h5>
                          <span><i class="fa fa-phone"></i></span>
                          +1 23584 2659
                        </h5>
                        <div class="verify">
                          <div class="verified">
                            <span><i class="la la-check"></i></span>
                            <a href="javascript:void(0)">Verified</a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="sidebar-right">
        <a class="sidebar-right-trigger" href="javascript:void(0)">
          <span><i class="fa fa-cog fa-spin"></i></span>
        </a>
        <div class="sidebar-right-inner">
          <div class="admin-settings">
            <div class="opt-background">
              <p>Font Family</p>
              <select class="form-control" name="theme_font" id="theme_font">
                <option value="nunito">Nunito</option>
                <option value="opensans">Open Sans</option>
              </select>
            </div>
            <div>
              <p>Primary Color</p>
              <div class="opt-nav-header-color">
                <span>
                  <input
                    type="radio"
                    name="navigation_header"
                    value="color_1"
                    class="filled-in chk-col-primary"
                    id="nav_header_color_1"
                  />
                  <label for="nav_header_color_1"></label>
                </span>
                <span>
                  <input
                    type="radio"
                    name="navigation_header"
                    value="color_2"
                    class="filled-in chk-col-primary"
                    id="nav_header_color_2"
                  />
                  <label for="nav_header_color_2"></label>
                </span>
                <span>
                  <input
                    type="radio"
                    name="navigation_header"
                    value="color_3"
                    class="filled-in chk-col-primary"
                    id="nav_header_color_3"
                  />
                  <label for="nav_header_color_3"></label>
                </span>
                <span>
                  <input
                    type="radio"
                    name="navigation_header"
                    value="color_4"
                    class="filled-in chk-col-primary"
                    id="nav_header_color_4"
                  />
                  <label for="nav_header_color_4"></label>
                </span>
                <span>
                  <input
                    type="radio"
                    name="navigation_header"
                    value="color_5"
                    class="filled-in chk-col-primary"
                    id="nav_header_color_5"
                  />
                  <label for="nav_header_color_5"></label>
                </span>
              </div>
            </div>
            <div class="opt-header-color">
              <p>Background Color</p>
              <div>
                <span>
                  <input
                    type="radio"
                    name="header_bg"
                    value="color_1"
                    class="filled-in chk-col-primary"
                    id="header_color_1"
                  />
                  <label for="header_color_1"></label>
                </span>
                <span>
                  <input
                    type="radio"
                    name="header_bg"
                    value="color_2"
                    class="filled-in chk-col-primary"
                    id="header_color_2"
                  />
                  <label for="header_color_2"></label>
                </span>
                <span>
                  <input
                    type="radio"
                    name="header_bg"
                    value="color_3"
                    class="filled-in chk-col-primary"
                    id="header_color_3"
                  />
                  <label for="header_color_3"></label>
                </span>
                <span>
                  <input
                    type="radio"
                    name="header_bg"
                    value="color_4"
                    class="filled-in chk-col-primary"
                    id="header_color_4"
                  />
                  <label for="header_color_4"></label>
                </span>
                <span>
                  <input
                    type="radio"
                    name="header_bg"
                    value="color_5"
                    class="filled-in chk-col-primary"
                    id="header_color_5"
                  />
                  <label for="header_color_5"></label>
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script
      data-cfasync="false"
      src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"
    ></script>
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/waves/waves.min.js"></script>
    <script src="vendor/validator/jquery.validate.js"></script>
    <script src="vendor/validator/validator-init.js"></script>
    <script src="vendor/scrollit/scrollIt.js"></script>
    <script src="js/plugins/scrollit-init.js"></script>
    <script src="js/scripts.js"></script>
    <script src="js/settings.js"></script>
    <script src="js/quixnav-init.js"></script>
    <script src="js/styleSwitcher.js"></script>
  </body>
</html>
